package com.example.daycareapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
//Programs page
class Programs : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_programs)
    }
}