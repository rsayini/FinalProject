package com.example.daycareapp

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.daycareapp.R.id.home
import android.content.Intent as Intent1
//Main activity
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

    }
// Navigation menu for Home, About, Programs
     override fun onOptionsItemSelected(item: MenuItem): Boolean {

        val id = item.itemId
        if(id == home) {

            startActivity(intent)
            return true
        }
        else if(id == R.id.about){
            return true
        }
        else if(id == R.id.programs){
            return true
        }
        return super.onOptionsItemSelected(item)
    }
// Button Next
     fun onClick(view: View){
           about()
    }
    //Function for About Activity
    fun about(){
        val intent = Intent1(this, About::class.java)
        startActivity(intent)
    }



}



