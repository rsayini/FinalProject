package com.example.daycareapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//About page
class About : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
    }
}